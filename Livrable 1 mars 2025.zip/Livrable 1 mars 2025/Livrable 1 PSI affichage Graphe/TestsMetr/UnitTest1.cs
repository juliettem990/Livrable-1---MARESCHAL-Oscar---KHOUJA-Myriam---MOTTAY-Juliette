﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestsMetr
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
